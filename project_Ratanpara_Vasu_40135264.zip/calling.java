import java.util.*;

public class calling extends Thread {

    String name;
    ArrayList<?> contactList;

    long endWaitTime = System.currentTimeMillis();

    calling(String name, ArrayList<?> contactList) {

        this.name = name;
        this.contactList = contactList;
    }

    @Override
    public void run() {
        
        try {
            // Send Messages Here
            for (Object person : contactList) {
                // Send Message to all Contacts
                for (calling t : exchange.threads) {
                    if (person.toString().equals(t.getCallerName())) {
                        // Sleeping
                        sleep(new Random().nextInt(50)+new Random().nextInt(50));
                        sendMessage(t.getCallerName());
                    }
                }
            }

            //Wait for 5 Seconds
            while (true) {
                // Sleeping
                sleep(new Random().nextInt(50)+new Random().nextInt(50));
                receiveMessage();
                if((System.currentTimeMillis() - endWaitTime) > 5000) {
                    System.out.println("\nProcess " + name + " has received no calls for 5 seconds, ending...\n");
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void sendMessage(String name) throws InterruptedException {
    
        // Creating New HashMap
        Map<String,String> map = new HashMap<>();
        // Sleeping
        Thread.sleep(new Random().nextInt(50)+new Random().nextInt(50));
        // Generate Timestamp
        long timestamp = System.currentTimeMillis();
        // Store reply message data
        map.put("uuid",UUID.randomUUID().toString());
        map.put("sender",getCallerName());
        map.put("receiver",name);
        map.put("timestamp",String.valueOf(timestamp));
        map.put("message",name+ " received intro message from " + getCallerName() + " ["+ timestamp + "]");

        // Put Message in replies queue
        exchange.requests.add(map);

        
    }

    public void receiveMessage() throws InterruptedException {

        // Check If New Messages arrives in requests queue
        Iterator<Map<String,String>> requestIterator = exchange.requests.iterator();
        
        while (requestIterator.hasNext()) {

            Map<String,String> map = requestIterator.next();

            // Found A message in Queue
            if(map.get("receiver").equals(getCallerName())){

                // Print Message
                exchange.printMessage(map.get("message"));
                // Remove intro message from queue
                requestIterator.remove();
                // Add reply message in queue
                Map<String,String> newMap = new HashMap<>();

                newMap.put("uuid",UUID.randomUUID().toString());
                newMap.put("sender",getCallerName());
                newMap.put("receiver",map.get("sender"));
                newMap.put("timestamp",map.get("timestamp"));
                newMap.put("message",map.get("sender")+ " received reply message from " + getCallerName() + " ["+ map.get("timestamp") + "]");
                
                // Add reply in replies Queue
                exchange.replies.add(newMap);
                
                // Reset Timer
                endWaitTime =  System.currentTimeMillis();

                // Sleeping
                Thread.sleep(new Random().nextInt(50)+new Random().nextInt(50));
            }
        }

        // Check If New Messages arrives in replies queue
        Iterator<Map<String,String>> replyIterator = exchange.replies.iterator();

        while (replyIterator.hasNext()) {

            Map<String,String> map = replyIterator.next();

            // Found A message in Queue
            if(map.get("receiver").equals(getCallerName())){

                // Print Message
                exchange.printMessage(map.get("message"));

                // Remove intro From Queue
                replyIterator.remove();
                // Reset Timer
                endWaitTime =  System.currentTimeMillis();
                
                // Sleeping
                Thread.sleep(new Random().nextInt(50)+new Random().nextInt(50));
            }
        }
    }

    public String getCallerName() {
        return name;
    }
}